var group__eth__interface__types1 =
[
    [ "ARM_ETH_INTERFACE_MII", "group__eth__interface__types1.html#ga468c848ddf75d7925130171af1ec2ac7", null ],
    [ "ARM_ETH_INTERFACE_RMII", "group__eth__interface__types1.html#gac0361b34fbec9c19840ad0349e4c388b", null ],
    [ "ARM_ETH_INTERFACE_SMII", "group__eth__interface__types1.html#ga24047d142be48bbc241e8d6eacb5cf7a", null ]
];