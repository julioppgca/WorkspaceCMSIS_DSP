var group__sai__companding__control =
[
    [ "ARM_SAI_COMPANDING_NONE", "group__sai__companding__control.html#ga185919d553cf9204e514136eb375ef08", null ],
    [ "ARM_SAI_COMPANDING_A_LAW", "group__sai__companding__control.html#gacfd6c74148c0ae90aa6eaaf8e69da3a9", null ],
    [ "ARM_SAI_COMPANDING_U_LAW", "group__sai__companding__control.html#ga7b571406bcce383140198e53312faee5", null ]
];