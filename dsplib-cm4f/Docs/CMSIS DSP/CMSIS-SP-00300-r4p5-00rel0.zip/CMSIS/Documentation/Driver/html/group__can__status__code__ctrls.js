var group__can__status__code__ctrls =
[
    [ "ARM_CAN_UNIT_STATE_INACTIVE", "group__can__status__code__ctrls.html#ga911a65cc31304d57d283a21476d9ade7", null ],
    [ "ARM_CAN_UNIT_STATE_ACTIVE", "group__can__status__code__ctrls.html#ga5f72c295ee2b829a8ae33b96466cc0e8", null ],
    [ "ARM_CAN_UNIT_STATE_PASSIVE", "group__can__status__code__ctrls.html#gace2db0f930f935054c21242f735e1922", null ],
    [ "ARM_CAN_LEC_NO_ERROR", "group__can__status__code__ctrls.html#ga5332a311f44caec256d59087c705e1e9", null ],
    [ "ARM_CAN_LEC_BIT_ERROR", "group__can__status__code__ctrls.html#ga0571c3c3e341ac0579aa713fdfdae77e", null ],
    [ "ARM_CAN_LEC_STUFF_ERROR", "group__can__status__code__ctrls.html#ga33cbda311f4c2f2464e4070dee78b2f2", null ],
    [ "ARM_CAN_LEC_CRC_ERROR", "group__can__status__code__ctrls.html#ga1380f80b709ca921634aecdaf34a24e5", null ],
    [ "ARM_CAN_LEC_FORM_ERROR", "group__can__status__code__ctrls.html#ga9f753ba50045b28653fb3215ec2e4b8a", null ],
    [ "ARM_CAN_LEC_ACK_ERROR", "group__can__status__code__ctrls.html#gaae6e827242137bc4d8976cd4ba73015f", null ]
];