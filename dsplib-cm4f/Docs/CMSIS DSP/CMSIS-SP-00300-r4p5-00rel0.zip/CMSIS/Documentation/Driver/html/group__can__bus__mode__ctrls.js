var group__can__bus__mode__ctrls =
[
    [ "ARM_CAN_MODE", "group__can__bus__mode__ctrls.html#gabbca99c46d478bcf822eee71cdf75dcd", [
      [ "ARM_CAN_MODE_INITIALIZATION", "_driver___c_a_n_8h.html#gabbca99c46d478bcf822eee71cdf75dcda9967a5ebaa045afe54d75e5629676ddc", null ],
      [ "ARM_CAN_MODE_NORMAL", "_driver___c_a_n_8h.html#gabbca99c46d478bcf822eee71cdf75dcdaa3190344bdf3452462e5c0518ac3cdc4", null ],
      [ "ARM_CAN_MODE_RESTRICTED", "_driver___c_a_n_8h.html#gabbca99c46d478bcf822eee71cdf75dcda22a9bb26e68c2a04f641d466040d755d", null ],
      [ "ARM_CAN_MODE_MONITOR", "_driver___c_a_n_8h.html#gabbca99c46d478bcf822eee71cdf75dcda904f68f08c84c4b85c763f5d98c574ab", null ],
      [ "ARM_CAN_MODE_LOOPBACK_INTERNAL", "_driver___c_a_n_8h.html#gabbca99c46d478bcf822eee71cdf75dcda8579315576baa43860a398a30fd527d8", null ],
      [ "ARM_CAN_MODE_LOOPBACK_EXTERNAL", "_driver___c_a_n_8h.html#gabbca99c46d478bcf822eee71cdf75dcda5ee1ba60abcf39d575e7cb309e641b9b", null ]
    ] ]
];