var group___c_a_n__events =
[
    [ "ARM_CAN_EVENT_SEND_COMPLETE", "group___c_a_n__events.html#ga486f0f35ebc7e3b5931ee68b56703503", null ],
    [ "ARM_CAN_EVENT_RECEIVE", "group___c_a_n__events.html#ga2c1082561eeae3b2b8132e81fc241e47", null ],
    [ "ARM_CAN_EVENT_RECEIVE_OVERRUN", "group___c_a_n__events.html#ga6c2d29b5c49d5cd18e97f5931157a94c", null ]
];