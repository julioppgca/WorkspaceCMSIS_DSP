var group__usart__parity__bit =
[
    [ "ARM_USART_PARITY_NONE", "group__usart__parity__bit.html#ga141a64650f99a1f642c3b3b6ced0eb8d", null ],
    [ "ARM_USART_PARITY_EVEN", "group__usart__parity__bit.html#gabc35e8dd2cbebb730abf36959e87a207", null ],
    [ "ARM_USART_PARITY_ODD", "group__usart__parity__bit.html#ga02f30181eedd3b04d650dd507bf40d6d", null ]
];